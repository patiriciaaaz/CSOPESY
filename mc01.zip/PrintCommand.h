#pragma once
#include "CommandType.h"

class PrintCommand : public CommandType{
	void executeCommand() override;
};

