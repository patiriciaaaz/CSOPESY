#include "PrintCommand.h"

void PrintCommand::executeCommand()
{
}
