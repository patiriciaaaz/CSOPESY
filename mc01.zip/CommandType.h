#pragma once

#include <string>
#include <iostream>

class CommandType
{
public:
	std::string commandTypeName;
	virtual ~CommandType() = default;
	virtual void executeCommand() = 0;
};

