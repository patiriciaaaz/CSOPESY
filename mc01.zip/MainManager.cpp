#include "MainManager.h"
#include <iostream>
#include <sstream>
#include <algorithm>

MainManager::MainManager() {
}

void MainManager::initialize() {
    std::cout << "Initializing OS...\n";
    isInitialized = true;
    config = std::make_shared<ConfigValues>("config.txt");
    cpuScheduler = std::make_shared<CPUAndScheduler>(config, shared_from_this());
}

void MainManager::showMenu()
{
    std::cout << R"(
 ,-----. ,---.   ,-----. ,------. ,------. ,---.,--.   ,--. 
'  .--./'   .-' '  .-.  '|  .--. '|  .---''   .-'\  `.'  /  
|  |    `.  `-. |  | |  ||  '--' ||  `--, `.  `-. '.    /   
'  '--'\.-'    |'  '-'  '|  | --' |  `---..-'    |  |  |    
 `-----'`-----'  `-----' `--'     `------'`-----'   `--'    
    )" << std::endl;
}

void MainManager::registerScreen(const std::string& name, std::shared_ptr<ConsoleFormat> screen) {
    screenRegistry[name] = screen;
}

bool MainManager::switchToScreen(const std::string& name) {
    auto it = screenRegistry.find(name);
    if (it != screenRegistry.end()) {
        activeScreen = it->second;
        system("cls");
        activeScreen->onEnabled();
        activeScreen->process();
        activeScreen = nullptr;
        system("cls");
        showMenu();  
        return true;
    }
    else {
        std::cout << "Screen not found: " << name << "\n";
        return false;
    }
}

void MainManager::listScreens() const {
    std::stringstream ss;

    if (screenRegistry.empty()) {
        ss << "No screens available.\n";
    }
    else {
        ss << "Registered Screens:\n";
        for (const auto& pair : screenRegistry) {
            ss << "- " << pair.first << "\n";
        }
    }

    ss << "\n";

    std::cout << ss.str();
}

bool MainManager::screenExists(const std::string& name) const {
    return screenRegistry.find(name) != screenRegistry.end();
}

std::vector<std::string> MainManager::tokenize(const std::string& line) {
    std::vector<std::string> tokens;
    std::istringstream iss(line);
    std::string word;
    while (iss >> word) {
        tokens.push_back(word);
    }
    return tokens;
}

void MainManager::run() {
    showMenu();  

    while (true) {
        std::cout << "root:/> ";
        std::string line;
        std::getline(std::cin, line);
        if (!isInitialized) {
            if (line == "in" || line == "initialize") {
                initialize();
                system("cls");
                showMenu();
            }
            else {
                std::cout << "Please initialize the OS." << std::endl << std::endl;
            }
        }
        else {
            std::vector<std::string> input = tokenize(line);

            if (input.size() == 1) {
                if (input[0] == "a") {
                    cpuScheduler->printCPUReport();
                }
                else if (input[0] == "b") {
                    std::cout << "=== Current Config Values ===\n";
                    std::cout << "CPU Count           : " << config->getNCPU() << "\n";
                    std::cout << "Scheduler           : " << config->getScheduler() << "\n";
                    std::cout << "Quantum Cycles      : " << config->getQuantumCycles() << "\n";
                    std::cout << "Batch Process Freq  : " << config->getBatchProcessFreq() << "\n";
                    std::cout << "Min Instructions    : " << config->getMinInstructions() << "\n";
                    std::cout << "Max Instructions    : " << config->getMaxInstructions() << "\n";
                    std::cout << "Delay Per Execution : " << config->getDelayPerExec() << "\n\n";
                }
                else if (input[0] == "marquee") { 
                    std::cout << "marquee" << std::endl << std::endl;
                }
                else if (input[0] == "clear") { 
                    system("cls");
                    showMenu();
                }
                else if (input[0] == "report-util") {
                    cpuScheduler->printCPUReportInText();
                }
                else if (input[0] == "st" || input[0] == "scheduler-start") {
                    cpuScheduler->schedulerStart();
                }
                else if (input[0] == "ss" || input[0] == "scheduler-stop") {
                    cpuScheduler->schedulerStop();
                }
                else {
                    std::cout << "Command not found." << std::endl << std::endl;
                }
            }
            else if (input.size() == 2) {
                if (input[0] + " " + input[1] == "screen -ls") {
                    cpuScheduler->printCPUReport();
                }
                else {
                    std::cout << "Command not found." << std::endl << std::endl;
                }
            }
            else if (input.size() == 3) {
                if (input[0] + " " + input[1] == "screen -s") {
                    std::string name = input[2];

                    if (screenExists(name)) {
                        std::cout << "Screen '" << name << "' already exists.\n\n";
                    }
                    else {
                        std::vector<std::shared_ptr<CommandType>> commands;
                        std::uint32_t ins = cpuScheduler->getRandomNoOfInstructions();
                        for (std::size_t i = 0; i < ins; ++i) {
                            commands.push_back(std::make_shared<PrintCommand>());
                        }
                        std::shared_ptr<Process> newProc = std::make_shared<Process>(name, commands, currentPId);

                        cpuScheduler->addProcessToProcessLine(newProc);

                        registerScreen(name, std::make_shared<ProcessConsole>(name, newProc));
                        switchToScreen(name);
                        currentPId++;
                    }
                }
                else if (input[0] + " " + input[1] == "screen -r") {
                    std::string name = input[2];

                    if (screenExists(name)) {
                        auto screen = screenRegistry.at(name);
                        auto procScreen = std::dynamic_pointer_cast<ProcessConsole>(screen);
                        if (procScreen) {
                            auto proc = procScreen->getProcess();
                            if (proc->hasFinished()) {
                                std::cout << "Screen '" << name << "' not found.\n\n";
                            }
                            else {
                                switchToScreen(name);
                            }
                        }
                    }
                    else {
                        std::cout << "Screen '" << name << "' not found.\n\n";
                    }
                }
                else {
                    std::cout << "Command not found." << std::endl << std::endl;
                }
            }
            else if (input.size() == 0) {
                std::cout;
            }
        }
    }
 }



